import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ['TF_USE_LEGACY_KERAS'] = 'True'
import re
import numpy as np
import tensorflow as tf
import sys
sys.path.append(os.path.abspath('/content/drive/MyDrive/Colab Notebooks/scheduling/'))
from data_generator import input_fn

import sys

sys.path.append(os.path.abspath('/content/drive/MyDrive/Colab\ Notebooks/'))
from delay_model import RouteNet_Fermi

TEST_PATH ='/content/drive/MyDrive/Colab\ Notebooks/scheduling/test1/'

optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)

model = RouteNet_Fermi()

loss_object = tf.keras.losses.MeanAbsolutePercentageError()

model.compile(loss=loss_object,
              optimizer=optimizer,
              run_eagerly=False)

best = None
best_mre = float('inf')

ckpt_dir = '/content/drive/MyDrive/Colab Notebooks/scheduling/delay/ckpt_dir/'

for f in os.listdir(ckpt_dir):
    if os.path.isfile(os.path.join(ckpt_dir, f)):
        reg = re.findall("\d+\.\d+", f)
        if len(reg) > 0:
            mre = float(reg[0])
            if mre <= best_mre:
                best = f.replace('.index', '')
                best = best.replace('.data', '')
                best = best.replace('-00000-of-00001', '')
                best_mre = mre

print("BEST CHECKOINT FOUND FOR: {}".format(best))

model.load_weights(os.path.join(ckpt_dir, best))

TEST_PATH ='/content/drive/MyDrive/Colab Notebooks/scheduling/test1/'
ds_test = input_fn(TEST_PATH, shuffle=True)
ds_test = ds_test.prefetch(tf.data.experimental.AUTOTUNE)

predictions = model.predict(ds_test, verbose=1)

verbose_output_file = '/content/drive/MyDrive/Colab Notebooks/scheduling/evaluation_verbose_delay_output.txt'

# Redirect stdout to the file
with open(verbose_output_file, 'w') as f:
    sys.stdout = f  # Redirect stdout to the file
    loss = model.evaluate(ds_test, verbose=1)  # Perform evaluation with verbose output
    sys.stdout = sys.__stdout__  # Reset stdout back to normal

np.save(f'/content/drive/MyDrive/Colab Notebooks/scheduling/predictions_delay_scheduling.npy', np.squeeze(predictions))



np.save(f'/content/drive/MyDrive/Colab Notebooks/scheduling/predictions_scheduling.npy', np.squeeze(predictions))
#np.save(f'predictions_jitter_scheduling.npy', np.squeeze(np.exp(predictions)))

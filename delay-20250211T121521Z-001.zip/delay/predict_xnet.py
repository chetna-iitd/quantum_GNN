import os
os.environ["CUDA_VISIBLE_DEVICES"] = "-1"
os.environ['TF_USE_LEGACY_KERAS'] = 'True'
import re
import numpy as np
import tensorflow as tf
import sys
sys.path.append(os.path.abspath('/content/drive/MyDrive/Colab Notebooks/scheduling/'))
from data_generator import input_fn

import sys

sys.path.append(os.path.abspath('/content/drive/MyDrive/Colab\ Notebooks/'))
from delay_model import RouteNet_Fermi

######### Iteration 1

optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)

model = RouteNet_Fermi()

loss_object = tf.keras.losses.MeanAbsolutePercentageError()

model.compile(loss=loss_object,
              optimizer=optimizer,
              run_eagerly=True)

best = None
best_mre = float('inf')


TEST_PATH ='/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test2_xNet/'

#####Update
TRAIN_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test1_xNet'

VALIDATION_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test2_xNet'
ds_train = input_fn(TRAIN_PATH, shuffle=True)
ds_train = ds_train.prefetch(tf.data.experimental.AUTOTUNE)
ds_train = ds_train.repeat()
ds_validation = input_fn(VALIDATION_PATH, shuffle=False)
ds_validation = ds_validation.prefetch(tf.data.experimental.AUTOTUNE)

optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)


model.fit(ds_train,
          epochs=1,
          steps_per_epoch=1,
          validation_data=ds_validation,
          validation_steps=1,
          use_multiprocessing=True)
          

ds_test = input_fn(TEST_PATH, shuffle=False)
ds_test = ds_test.prefetch(tf.data.experimental.AUTOTUNE)


######################  Iteration 2  ###################


optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)

model = RouteNet_Fermi()

loss_object = tf.keras.losses.MeanAbsolutePercentageError()

model.compile(loss=loss_object,
              optimizer=optimizer,
              run_eagerly=True)

best = None
best_mre = float('inf')



TEST_PATH ='/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test3_xNet/'

#####Update
TRAIN_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test2_xNet'

VALIDATION_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test3_xNet'
ds_train = input_fn(TRAIN_PATH, shuffle=True)
ds_train = ds_train.prefetch(tf.data.experimental.AUTOTUNE)
ds_train = ds_train.repeat()
ds_validation = input_fn(VALIDATION_PATH, shuffle=False)
ds_validation = ds_validation.prefetch(tf.data.experimental.AUTOTUNE)

optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)


model.fit(ds_train,
          epochs=1,
          steps_per_epoch=1,
          validation_data=ds_validation,
          validation_steps=1,
          use_multiprocessing=True)
          

ds_test = input_fn(TEST_PATH, shuffle=False)
ds_test = ds_test.prefetch(tf.data.experimental.AUTOTUNE)

######################  Iteration 3  ###################


optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)

model = RouteNet_Fermi()

loss_object = tf.keras.losses.MeanAbsolutePercentageError()

model.compile(loss=loss_object,
              optimizer=optimizer,
              run_eagerly=True)

best = None
best_mre = float('inf')



TEST_PATH ='/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test4_xNet/'

#####Update
TRAIN_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test3_xNet'

VALIDATION_PATH = '/content/drive/MyDrive/Colab Notebooks/scheduling/xNet/test4_xNet'
ds_train = input_fn(TRAIN_PATH, shuffle=True)
ds_train = ds_train.prefetch(tf.data.experimental.AUTOTUNE)
ds_train = ds_train.repeat()
ds_validation = input_fn(VALIDATION_PATH, shuffle=False)
ds_validation = ds_validation.prefetch(tf.data.experimental.AUTOTUNE)

optimizer = tf.keras.optimizers.legacy.Adam(learning_rate=0.001)


model.fit(ds_train,
          epochs=1,
          steps_per_epoch=1,
          validation_data=ds_validation,
          validation_steps=1,
          use_multiprocessing=True)
          

ds_test = input_fn(TEST_PATH, shuffle=False)
ds_test = ds_test.prefetch(tf.data.experimental.AUTOTUNE)

#model.evaluate(ds_test,10)